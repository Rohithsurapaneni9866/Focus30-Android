# Focus30 Android

A native Android career consistency tracker built with Kotlin, Jetpack Compose, Room and WorkManager.

## Features
- 30-day career plan with Foundation, Backend, Project and Career phases
- Daily 3-hour schedule
- Mark days complete and track weekly progress
- Daily habit checklist
- Record focused minutes, phone distraction minutes and notes
- Local Room database; progress remains on the device
- Daily reminder notification (tap the bell in the app)

## Build the APK
1. Install Android Studio (latest stable) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Let Gradle sync finish. Use JDK 17.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your Android phone and install it. Allow installation from that source if Android asks.

## Notes
- The reminder is scheduled as a daily WorkManager task. Android may delay background work to preserve battery; it is not an exact-to-the-minute alarm.
- Notification permission is requested on Android 13 and newer.
- Phone usage is manually recorded. Android does not expose reliable per-app usage totals without additional Usage Access permission and a dedicated usage-statistics screen.
- This is a source project, not a prebuilt APK. Build it with Android Studio to create the installable APK.
