package com.rohith.focus30

import android.Manifest
import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.*
import androidx.work.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

@Entity(tableName = "day_progress")
data class DayProgress(
    @PrimaryKey val day: Int,
    val completed: Boolean = false,
    val notes: String = "",
    val focusMinutes: Int = 0,
    val phoneMinutes: Int = 0,
    val habitsMask: Int = 0
)

@Dao
interface ProgressDao {
    @Query("SELECT * FROM day_progress ORDER BY day")
    fun observeAll(): Flow<List<DayProgress>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(item: DayProgress)
    @Query("SELECT * FROM day_progress WHERE day = :day")
    suspend fun get(day: Int): DayProgress?
}

@Database(entities = [DayProgress::class], version = 1, exportSchema = false)
abstract class FocusDatabase : RoomDatabase() {
    abstract fun progressDao(): ProgressDao
    companion object {
        @Volatile private var INSTANCE: FocusDatabase? = null
        fun get(context: Context): FocusDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context, FocusDatabase::class.java, "focus30.db").build().also { INSTANCE = it }
        }
    }
}

data class DayTask(val title: String, val phase: String)
val dayTasks = listOf(
    "Resume and target roles","C# fundamentals","OOP concepts","Collections and LINQ","SQL fundamentals","ASP.NET Core architecture","Weekly revision and quiz",
    "Entity Framework Core","Build CRUD APIs","JWT authentication","Validation and logging","Postman and API testing","Project architecture","Complete backend mini API",
    "Create project and SQL database","Registration and login","Job management APIs","React dashboard","Search and filtering","Frontend-backend integration","Polish project and README",
    "Finalise ATS resume","Improve GitHub profile","Update LinkedIn","Apply to 5 jobs","Coding and SQL practice","Technical interview preparation","Apply to 5 jobs and contact recruiters","Mock interview","30-day review"
).mapIndexed { i, title -> DayTask(title, when(i) { in 0..6 -> "Foundation"; in 7..13 -> "Backend"; in 14..20 -> "Project"; else -> "Career" }) }

class FocusViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = FocusDatabase.get(app).progressDao()
    val records = dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun update(day: Int, transform: (DayProgress) -> DayProgress) = viewModelScope.launch {
        val old = dao.get(day) ?: DayProgress(day)
        dao.save(transform(old))
    }
    fun toggle(day: Int) = update(day) { it.copy(completed = !it.completed) }
    fun saveDetails(day: Int, notes: String, focus: Int, phone: Int, mask: Int) =
        update(day) { it.copy(notes = notes, focusMinutes = focus, phoneMinutes = phone, habitsMask = mask) }
    fun scheduleReminder(hour: Int, minute: Int) {
        val data = workDataOf("hour" to hour, "minute" to minute)
        val request = PeriodicWorkRequestBuilder<ReminderWorker>(24, TimeUnit.HOURS)
            .setInputData(data).build()
        WorkManager.getInstance(getApplication()).enqueueUniquePeriodicWork("focus30_daily_reminder", ExistingPeriodicWorkPolicy.UPDATE, request)
    }
}

class ReminderWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel("focus30", "Focus30 reminders", NotificationManager.IMPORTANCE_DEFAULT))
        }
        if (Build.VERSION.SDK_INT < 33 || applicationContext.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            val notification = if (Build.VERSION.SDK_INT >= 26)
                android.app.Notification.Builder(applicationContext, "focus30")
                    .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Focus30")
                    .setContentText("Your daily 3-hour career session is waiting. Start with one task.")
                    .setAutoCancel(true).build()
            else @Suppress("DEPRECATION") android.app.Notification.Builder(applicationContext)
                .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Focus30")
                .setContentText("Your daily career session is waiting.").build()
            manager.notify(30, notification)
        }
        return Result.success()
    }
}

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { Focus30App() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Focus30App(vm: FocusViewModel = viewModel()) {
    val records by vm.records.collectAsState()
    var tab by remember { mutableStateOf(0) }
    var selectedDay by remember { mutableIntStateOf(1) }
    val recordMap = records.associateBy { it.day }
    val completed = records.count { it.completed }
    val pct = completed * 100 / 30
    val green = Color(0xFF16865A)
    MaterialTheme(colorScheme = lightColorScheme(primary = green, secondary = Color(0xFF426B9B), background = Color(0xFFF5F7F8))) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Column { Text("FOCUS30", fontWeight = FontWeight.Bold); Text("30 days • 90 focused hours", style = MaterialTheme.typography.labelSmall) } },
                    actions = { IconButton(onClick = { vm.scheduleReminder(9, 0) }) { Icon(Icons.Default.NotificationsActive, "Enable daily reminder") } }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Today, null) }, label = { Text("Today") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.CalendarMonth, null) }, label = { Text("Plan") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Insights, null) }, label = { Text("Progress") })
                }
            }
        ) { padding ->
            when (tab) {
                0 -> TodayScreen(Modifier.padding(padding), selectedDay, { selectedDay = it }, recordMap[selectedDay] ?: DayProgress(selectedDay), vm, completed, pct)
                1 -> PlanScreen(Modifier.padding(padding), recordMap, onSelect = { selectedDay = it; tab = 0 }, onToggle = vm::toggle)
                else -> ProgressScreen(Modifier.padding(padding), records, completed, pct)
            }
        }
    }
}

@Composable
fun SummaryCard(completed: Int, pct: Int) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE9F4EE))) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("YOUR 30-DAY PROGRESS", style = MaterialTheme.typography.labelMedium, color = Color(0xFF286345))
            Row(verticalAlignment = Alignment.Bottom) {
                Text("$pct%", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold, color = Color(0xFF16865A))
                Spacer(Modifier.width(8.dp)); Text("$completed of 30 days completed", modifier = Modifier.padding(bottom = 7.dp))
            }
            LinearProgressIndicator(progress = { pct / 100f }, modifier = Modifier.fillMaxWidth(), color = Color(0xFF16865A))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${completed * 3} hours logged", style = MaterialTheme.typography.labelMedium)
                Text("${30 - completed} days left", style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@Composable
fun TodayScreen(modifier: Modifier, day: Int, onDay: (Int) -> Unit, record: DayProgress, vm: FocusViewModel, completed: Int, pct: Int) {
    var notes by remember(day, record.notes) { mutableStateOf(record.notes) }
    var focus by remember(day, record.focusMinutes) { mutableStateOf(record.focusMinutes.toString()) }
    var phone by remember(day, record.phoneMinutes) { mutableStateOf(record.phoneMinutes.toString()) }
    var mask by remember(day, record.habitsMask) { mutableIntStateOf(record.habitsMask) }
    val habits = listOf("3 hours focused study","Phone away during study","Complete one coding exercise","Work on job preparation","Review tomorrow's tasks")
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Your career dashboard", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            SummaryCard(completed, pct)
        }
        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("DAY $day OF 30", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
                    Text(dayTasks[day - 1].title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text(dayTasks[day - 1].phase, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { if (day > 1) onDay(day - 1) }, enabled = day > 1) { Text("Previous") }
                        OutlinedButton(onClick = { if (day < 30) onDay(day + 1) }, enabled = day < 30) { Text("Next day") }
                    }
                    Button(onClick = { vm.toggle(day) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(if (record.completed) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked, null)
                        Spacer(Modifier.width(8.dp)); Text(if (record.completed) "Mark incomplete" else "Mark day completed")
                    }
                }
            }
        }
        item {
            Text("Daily 3-hour schedule", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            listOf("9:00–10:00  Technical learning • 60 min","10:00–11:00  Practical development • 60 min","11:00–11:45  Career preparation • 45 min","11:45–12:00  Daily review • 15 min").forEach {
                ListItem(headlineContent = { Text(it) }, leadingContent = { Icon(Icons.Default.Schedule, null) })
            }
        }
        item { Text("Daily habits", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        items(habits.size) { i ->
            Card {
                Row(Modifier.fillMaxWidth().clickable { mask = mask xor (1 shl i) }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = mask and (1 shl i) != 0, onCheckedChange = { mask = if (it) mask or (1 shl i) else mask and (1 shl i).inv() })
                    Text(habits[i])
                }
            }
        }
        item {
            Text("Phone distraction (minutes)")
            OutlinedTextField(phone, { phone = it.filter(Char::isDigit) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Text("Focused study minutes")
            OutlinedTextField(focus, { focus = it.filter(Char::isDigit) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Text("What did you learn today?")
            OutlinedTextField(notes, { notes = it }, modifier = Modifier.fillMaxWidth(), minLines = 3)
            Button(onClick = { vm.saveDetails(day, notes, focus.toIntOrNull() ?: 0, phone.toIntOrNull() ?: 0, mask) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("Save today's progress")
            }
        }
    }
}

@Composable
fun PlanScreen(records: Map<Int, DayProgress>, onSelect: (Int) -> Unit, onToggle: (Int) -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("30-day plan", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        items((1..30).toList()) { day ->
            val task = dayTasks[day - 1]
            val done = records[day]?.completed == true
            Card {
                Row(Modifier.fillMaxWidth().clickable { onSelect(day) }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(done, onCheckedChange = { onToggle(day) })
                    Column(Modifier.weight(1f)) {
                        Text("Day $day • ${task.phase}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        Text(task.title, fontWeight = FontWeight.Medium)
                    }
                    Icon(Icons.Default.ChevronRight, null)
                }
            }
        }
    }
}

@Composable
fun ProgressScreen(modifier: Modifier, records: List<DayProgress>, completed: Int, pct: Int) {
    val totalFocus = records.sumOf { it.focusMinutes }
    val totalPhone = records.sumOf { it.phoneMinutes }
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Your progress", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { SummaryCard(completed, pct) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Focus time", "$totalFocus min", Modifier.weight(1f))
                MetricCard("Phone time", "$totalPhone min", Modifier.weight(1f))
            }
        }
        items((0..3).toList()) { week ->
            val start = week * 7 + 1
            val end = minOf(start + 6, 30)
            val count = (start..end).count { day -> records.any { it.day == day && it.completed } }
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Week ${week + 1} • ${dayTasks[start - 1].phase}", fontWeight = FontWeight.Bold)
                    Text("$count of ${end - start + 1} days completed")
                    LinearProgressIndicator(progress = { count.toFloat() / (end - start + 1) }, modifier = Modifier.fillMaxWidth())
                }
            }
        }
        item { Text("Tip: consistency matters more than a perfect streak. If you miss a day, continue the next day.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) { Column(Modifier.padding(14.dp)) { Text(title, style = MaterialTheme.typography.labelMedium); Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) } }
}
